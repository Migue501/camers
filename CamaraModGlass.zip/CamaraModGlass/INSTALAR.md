# Cómo conseguir e instalar el APK

## Opción A: sin PC (GitHub, gratis, desde el navegador del celu)
1. Creá cuenta en https://github.com y un repositorio nuevo (ej. "CamaraModGlass").
2. Subí TODO el contenido de esta carpeta (incluida la carpeta oculta .github). Add file > Upload files.
3. Entrá a la pestaña "Actions" > "Build APK" > "Run workflow". Tarda unos 5 minutos.
4. Cuando termine, abrí la ejecución y bajá el archivo "CamaraModGlass-apk" (viene en .zip, adentro está app-debug.apk).
5. Instalalo en el celu (permití "instalar apps desconocidas" cuando lo pida).

## Opción B: con PC
1. Bajá Android Studio: https://developer.android.com/studio
2. File > Open > elegí esta carpeta. Esperá el Gradle sync.
3. Build > Build APK(s). Queda en app/build/outputs/apk/debug/app-debug.apk
