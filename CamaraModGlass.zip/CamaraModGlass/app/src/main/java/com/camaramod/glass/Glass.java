package com.camaramod.glass;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/** Estética "liquid glass": cuerpo translúcido, brillo especular superior, borde refractivo doble. */
final class Glass {
    static float D = 1f;

    static void init(Context c) { D = c.getResources().getDisplayMetrics().density; }
    static int dp(float v) { return Math.round(v * D); }

    static final int ACCENT = 0xFF6FB8FF;

    // ------------------------------------------------------------------ fondo de vidrio
    static final class Bg extends Drawable {
        private final float radiusDp;
        private final boolean selected;
        private final int tint;
        private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tintP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint shine = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rim2 = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        /** radiusDp < 0 => píldora/círculo completo */
        Bg(float radiusDp, boolean selected, int tint) {
            this.radiusDp = radiusDp;
            this.selected = selected;
            this.tint = tint;
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(dp(1.3f));
            rim2.setStyle(Paint.Style.STROKE);
            rim2.setStrokeWidth(dp(0.8f));
            tintP.setColor(tint);
        }

        @Override protected void onBoundsChange(Rect b) {
            float l = b.left, t = b.top, rr = b.right, bt = b.bottom;
            body.setShader(new LinearGradient(l, t, rr, bt,
                    selected ? new int[]{0x78FFFFFF, 0x30FFFFFF} : new int[]{0x42FFFFFF, 0x10FFFFFF},
                    null, Shader.TileMode.CLAMP));
            shine.setShader(new LinearGradient(0, t, 0, t + b.height() * 0.5f,
                    new int[]{0x70FFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
            rim.setShader(new LinearGradient(l, t, rr, bt,
                    new int[]{0xF2FFFFFF, 0x38FFFFFF, 0x18FFFFFF, 0xA8FFFFFF},
                    new float[]{0f, 0.35f, 0.65f, 1f}, Shader.TileMode.CLAMP));
            rim2.setShader(new LinearGradient(l, bt, rr, t,
                    new int[]{0x55FFFFFF, 0x00FFFFFF, 0x40FFFFFF},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            glow.setShader(new RadialGradient((l + rr) / 2f, bt, Math.max(1, b.width() * 0.6f),
                    new int[]{0x2AFFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        }

        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            if (b.isEmpty()) return;
            float rad = radiusDp < 0 ? Math.min(b.width(), b.height()) / 2f : dp(radiusDp);
            r.set(b);
            r.inset(dp(0.8f), dp(0.8f));
            c.drawRoundRect(r, rad, rad, body);
            if (tint != 0) c.drawRoundRect(r, rad, rad, tintP);
            c.drawRoundRect(r, rad, rad, glow);

            c.save();
            c.clipRect(r.left, r.top, r.right, r.top + r.height() * 0.5f);
            RectF s = new RectF(r);
            s.inset(dp(2f), dp(2f));
            c.drawRoundRect(s, Math.max(0, rad - dp(2f)), Math.max(0, rad - dp(2f)), shine);
            c.restore();

            c.drawRoundRect(r, rad, rad, rim);
            RectF in = new RectF(r);
            in.inset(dp(2.4f), dp(2.4f));
            c.drawRoundRect(in, Math.max(0, rad - dp(2.4f)), Math.max(0, rad - dp(2.4f)), rim2);
        }

        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter f) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    // ------------------------------------------------------------------ feedback táctil
    static void press(final View v) {
        v.setOnTouchListener((view, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(new android.view.animation.OvershootInterpolator(2.5f)).start();
                    break;
            }
            return false;
        });
    }

    static ImageView iconButton(Context c, int res, int sizeDp) {
        ImageView v = new ImageView(c);
        v.setImageResource(res);
        int pad = dp(sizeDp * 0.27f);
        v.setPadding(pad, pad, pad, pad);
        v.setBackground(new Bg(-1, false, 0));
        v.setClickable(true);
        press(v);
        return v;
    }

    static void styleChip(TextView t, boolean sel) {
        t.setBackground(new Bg(-1, sel, sel ? 0x4458B8FF : 0));
        t.setTextColor(sel ? Color.WHITE : 0xDDFFFFFF);
    }

    static TextView chip(Context c, String text, boolean sel) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(13f);
        t.setSingleLine(true);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        t.setClickable(true);
        styleChip(t, sel);
        press(t);
        return t;
    }

    // ------------------------------------------------------------------ botón REC
    static final class RecButton extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float prog = 0f;
        private ValueAnimator va;

        RecButton(Context c) {
            super(c);
            setBackground(new Bg(-1, false, 0));
            setClickable(true);
            press(this);
        }

        void setRecording(boolean rec) {
            if (va != null) va.cancel();
            va = ValueAnimator.ofFloat(prog, rec ? 1f : 0f);
            va.setDuration(260);
            va.addUpdateListener(a -> { prog = (float) a.getAnimatedValue(); invalidate(); });
            va.start();
        }

        @Override protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float maxR = getWidth() * 0.31f;
            float rad = maxR * (1f - 0.35f * prog);
            float corner = rad * (1f - 0.68f * prog);
            p.setShader(new RadialGradient(cx - rad * 0.25f, cy - rad * 0.35f, rad * 1.6f,
                    new int[]{0xFFFF8A80, 0xFFE5202E}, null, Shader.TileMode.CLAMP));
            c.drawRoundRect(cx - rad, cy - rad, cx + rad, cy + rad, corner, corner, p);
            gloss.setShader(new LinearGradient(0, cy - rad, 0, cy, 0x90FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            c.save();
            c.clipRect(cx - rad, cy - rad, cx + rad, cy);
            c.drawRoundRect(cx - rad + dp(2), cy - rad + dp(2), cx + rad - dp(2), cy + rad - dp(2), corner, corner, gloss);
            c.restore();
        }
    }

    // ------------------------------------------------------------------ overlay (cuadrícula + nivel)
    static final class Overlay extends View {
        HorizonEngine engine;
        boolean grid = false;
        boolean showLevel = true;
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ref = new Paint(Paint.ANTI_ALIAS_FLAG);

        Overlay(Context c) {
            super(c);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            ref.setStyle(Paint.Style.STROKE);
            ref.setStrokeCap(Paint.Cap.ROUND);
            setClickable(false);
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            if (grid) {
                line.setColor(0x55FFFFFF);
                line.setStrokeWidth(dp(0.8f));
                for (int i = 1; i <= 2; i++) {
                    c.drawLine(w * i / 3f, 0, w * i / 3f, h, line);
                    c.drawLine(0, h * i / 3f, w, h * i / 3f, line);
                }
            }
            if (!showLevel || engine == null) return;
            float t = engine.liveTiltDeg;
            boolean ok = Math.abs(t) < 0.8f;
            float cx = w / 2f, cy = h / 2f, half = dp(46);
            ref.setStrokeWidth(dp(1.6f));
            ref.setColor(0x99FFFFFF);
            c.drawLine(cx - dp(86), cy, cx - dp(62), cy, ref);
            c.drawLine(cx + dp(62), cy, cx + dp(86), cy, ref);
            line.setStrokeWidth(dp(2.2f));
            line.setColor(ok ? 0xFF7CFFB2 : 0xFFFFD66B);
            c.save();
            c.rotate(t, cx, cy);
            c.drawLine(cx - half, cy, cx + half, cy, line);
            c.restore();
        }
    }
}
