package com.camaramod.glass;

import android.graphics.SurfaceTexture;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLExt;
import android.opengl.EGLSurface;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * La cámara escribe en una SurfaceTexture (textura OES). Cada frame se dibuja con un shader
 * que aplica la homografía de HorizonEngine y se envía a: (1) la vista previa y (2) el encoder.
 * Así lo que ves es exactamente lo que se graba.
 */
final class GlPipeline implements SurfaceTexture.OnFrameAvailableListener {

    interface Ready { void onReady(); }

    private static final int EGL_RECORDABLE_ANDROID = 0x3142;

    private static final String VS =
            "attribute vec2 aPos;\n" +
            "varying vec2 vNdc;\n" +
            "void main(){ vNdc = aPos; gl_Position = vec4(aPos, 0.0, 1.0); }\n";

    private static final String FS =
            "#extension GL_OES_EGL_image_external : require\n" +
            "precision highp float;\n" +
            "varying vec2 vNdc;\n" +
            "uniform samplerExternalOES sTex;\n" +
            "uniform mat4 uTexMat;\n" +
            "uniform mat3 uM;\n" +
            "uniform float uF;\n" +
            "uniform float uZoom;\n" +
            "uniform float uAspect;\n" +
            "uniform float uRot180;\n" +
            "uniform float uMirror;\n" +
            "void main(){\n" +
            "  vec2 p = vec2(vNdc.x, vNdc.y * uAspect);\n" +
            "  vec3 d = vec3(p / (uF * uZoom), -1.0);\n" +
            "  vec3 r = uM * d;\n" +
            "  vec2 n = r.xy / (-r.z) * uF;\n" +
            "  vec2 uv = vec2(0.5 + 0.5 * n.x, 0.5 + 0.5 * n.y / uAspect);\n" +
            "  if (uRot180 > 0.5) uv = vec2(1.0) - uv;\n" +
            "  if (uMirror > 0.5) uv.x = 1.0 - uv.x;\n" +
            "  vec4 t = uTexMat * vec4(uv, 0.0, 1.0);\n" +
            "  gl_FragColor = texture2D(sTex, t.xy);\n" +
            "}\n";

    private final HorizonEngine engine;
    private final HandlerThread thread = new HandlerThread("GlPipeline");
    private Handler hnd;

    private EGLDisplay dpy = EGL14.EGL_NO_DISPLAY;
    private EGLContext ctx = EGL14.EGL_NO_CONTEXT;
    private EGLConfig cfg;
    private EGLSurface previewSurf = EGL14.EGL_NO_SURFACE;
    private EGLSurface recSurf = EGL14.EGL_NO_SURFACE;

    private int prog, texId;
    private int aPos, uTexMat, uM, uF, uZoom, uAspect, uRot180, uMirror, uTex;
    private SurfaceTexture camTex;
    private Surface camSurface;
    private FloatBuffer quad;
    private volatile boolean released;

    private final float[] texMat = new float[16];
    private final float[] m3 = new float[9];
    private final float[] zoom = new float[1];

    // parámetros que fija la Activity
    private volatile float focal = 1.5f;
    private volatile float aspect = 9f / 16f;
    private volatile int sensorOrientation = 90;
    private volatile int displayRotDeg = 90;
    private volatile boolean front = false;
    private volatile boolean stab = false;

    GlPipeline(HorizonEngine engine) { this.engine = engine; }

    void setParams(float focalNdc, float aspectHW, int sensorOrientation, boolean front, boolean stab, boolean tsRealtime) {
        this.focal = focalNdc;
        this.aspect = aspectHW;
        this.sensorOrientation = sensorOrientation;
        this.front = front;
        this.stab = stab;
        engine.comparable = tsRealtime;
    }

    void setStab(boolean s) { stab = s; }
    void setDisplayRotation(int deg) { displayRotDeg = deg; engine.rotDeg = deg; }

    SurfaceTexture getCameraTexture() { return camTex; }
    Surface getCameraSurface() { return camSurface; }

    void start(final SurfaceTexture previewSt, final int w, final int h, final Ready cb) {
        thread.start();
        hnd = new Handler(thread.getLooper());
        hnd.post(() -> {
            try {
                initEgl(previewSt);
                initGl();
                camTex = new SurfaceTexture(texId);
                camTex.setDefaultBufferSize(w, h);
                camTex.setOnFrameAvailableListener(GlPipeline.this, hnd);
                camSurface = new Surface(camTex);
                cb.onReady();
            } catch (RuntimeException e) {
                e.printStackTrace();
            }
        });
    }

    // ------------------------------------------------------------ grabación

    void startRecording(final Surface s) {
        hnd.post(() -> {
            try {
                recSurf = EGL14.eglCreateWindowSurface(dpy, cfg, s, new int[]{EGL14.EGL_NONE}, 0);
            } catch (RuntimeException e) {
                recSurf = EGL14.EGL_NO_SURFACE;
            }
        });
    }

    /** Bloquea hasta que el EGLSurface del encoder se destruyó (hay que hacerlo antes de MediaRecorder.stop). */
    void stopRecording() {
        final CountDownLatch l = new CountDownLatch(1);
        hnd.post(() -> {
            if (recSurf != EGL14.EGL_NO_SURFACE) {
                EGL14.eglMakeCurrent(dpy, previewSurf, previewSurf, ctx);
                EGL14.eglDestroySurface(dpy, recSurf);
                recSurf = EGL14.EGL_NO_SURFACE;
            }
            l.countDown();
        });
        try { l.await(800, TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }
    }

    // ------------------------------------------------------------ dibujo

    @Override public void onFrameAvailable(SurfaceTexture st) { drawFrame(); }

    private void drawFrame() {
        if (released) return;
        try {
            EGL14.eglMakeCurrent(dpy, previewSurf, previewSurf, ctx);
            camTex.updateTexImage();
            camTex.getTransformMatrix(texMat);
            long ts = camTex.getTimestamp();

            if (stab && !front) {
                engine.compute(ts, displayRotDeg, focal, aspect, m3, zoom);
            } else {
                for (int i = 0; i < 9; i++) m3[i] = 0;
                m3[0] = m3[4] = m3[8] = 1;
                zoom[0] = 1f;
            }

            draw(previewSurf);
            EGL14.eglSwapBuffers(dpy, previewSurf);

            if (recSurf != EGL14.EGL_NO_SURFACE) {
                draw(recSurf);
                EGLExt.eglPresentationTimeANDROID(dpy, recSurf, ts);
                EGL14.eglSwapBuffers(dpy, recSurf);
            }
        } catch (RuntimeException e) {
            // frame perdido: seguimos
        }
    }

    private void draw(EGLSurface s) {
        EGL14.eglMakeCurrent(dpy, s, s, ctx);
        int[] v = new int[1];
        EGL14.eglQuerySurface(dpy, s, EGL14.EGL_WIDTH, v, 0);
        int w = v[0];
        EGL14.eglQuerySurface(dpy, s, EGL14.EGL_HEIGHT, v, 0);
        int h = v[0];
        GLES20.glViewport(0, 0, w, h);
        GLES20.glClearColor(0, 0, 0, 1);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        GLES20.glUseProgram(prog);

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId);
        GLES20.glUniform1i(uTex, 0);
        GLES20.glUniformMatrix4fv(uTexMat, 1, false, texMat, 0);
        GLES20.glUniformMatrix3fv(uM, 1, false, m3, 0);
        GLES20.glUniform1f(uF, focal);
        GLES20.glUniform1f(uZoom, zoom[0]);
        GLES20.glUniform1f(uAspect, aspect);

        int b = front ? (sensorOrientation + displayRotDeg) % 360
                      : (sensorOrientation - displayRotDeg + 360) % 360;
        GLES20.glUniform1f(uRot180, b == 180 ? 1f : 0f);
        // el archivo grabado no va en espejo; la vista previa de la frontal sí
        GLES20.glUniform1f(uMirror, (front && s == previewSurf) ? 1f : 0f);

        quad.position(0);
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, quad);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glDisableVertexAttribArray(aPos);
    }

    // ------------------------------------------------------------ init / release

    private void initEgl(SurfaceTexture previewSt) {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        int[] ver = new int[2];
        EGL14.eglInitialize(dpy, ver, 0, ver, 1);
        int[] attr = {
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL_RECORDABLE_ANDROID, 1,
                EGL14.EGL_NONE};
        EGLConfig[] cfgs = new EGLConfig[1];
        int[] n = new int[1];
        EGL14.eglChooseConfig(dpy, attr, 0, cfgs, 0, 1, n, 0);
        cfg = cfgs[0];
        ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT,
                new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE}, 0);
        previewSurf = EGL14.eglCreateWindowSurface(dpy, cfg, previewSt, new int[]{EGL14.EGL_NONE}, 0);
        EGL14.eglMakeCurrent(dpy, previewSurf, previewSurf, ctx);
        EGL14.eglSwapInterval(dpy, 0);
    }

    private void initGl() {
        int vs = compile(GLES20.GL_VERTEX_SHADER, VS);
        int fs = compile(GLES20.GL_FRAGMENT_SHADER, FS);
        prog = GLES20.glCreateProgram();
        GLES20.glAttachShader(prog, vs);
        GLES20.glAttachShader(prog, fs);
        GLES20.glLinkProgram(prog);
        aPos = GLES20.glGetAttribLocation(prog, "aPos");
        uTex = GLES20.glGetUniformLocation(prog, "sTex");
        uTexMat = GLES20.glGetUniformLocation(prog, "uTexMat");
        uM = GLES20.glGetUniformLocation(prog, "uM");
        uF = GLES20.glGetUniformLocation(prog, "uF");
        uZoom = GLES20.glGetUniformLocation(prog, "uZoom");
        uAspect = GLES20.glGetUniformLocation(prog, "uAspect");
        uRot180 = GLES20.glGetUniformLocation(prog, "uRot180");
        uMirror = GLES20.glGetUniformLocation(prog, "uMirror");

        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        texId = t[0];
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);

        float[] q = {-1, -1, 1, -1, -1, 1, 1, 1};
        quad = ByteBuffer.allocateDirect(q.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        quad.put(q).position(0);
    }

    private static int compile(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        return s;
    }

    void release() {
        if (released) return;
        released = true;
        final CountDownLatch l = new CountDownLatch(1);
        hnd.post(() -> {
            try {
                if (camTex != null) { camTex.setOnFrameAvailableListener(null); }
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
                if (recSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, recSurf);
                if (previewSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, previewSurf);
                if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx);
                EGL14.eglTerminate(dpy);
                if (camSurface != null) camSurface.release();
                if (camTex != null) camTex.release();
            } catch (RuntimeException ignored) { }
            l.countDown();
        });
        try { l.await(1000, TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }
        thread.quitSafely();
    }
}
