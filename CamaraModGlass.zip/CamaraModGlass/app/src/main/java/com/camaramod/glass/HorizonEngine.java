package com.camaramod.glass;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.HandlerThread;

/**
 * Motor de estabilización digital + Horizon Lock.
 *
 * - Lee la orientación 3D fusionada (giroscopio + acelerómetro) a ~200 Hz.
 * - Guarda en un buffer circular la orientación real y la orientación "suavizada".
 * - Para cada frame de cámara busca la muestra más cercana a su timestamp
 *   (sincronización por tiempo => la corrección cae sobre el frame correcto).
 * - Calcula una homografía 3x3: lo que vería una cámara virtual suavizada y con el horizonte nivelado.
 * - Calcula el zoom mínimo necesario para que no se vean bordes negros.
 */
final class HorizonEngine implements SensorEventListener {
    private static final int N = 1024;
    private static final float HALF_PI = (float) (Math.PI / 2);

    private final SensorManager sm;
    private Sensor sensor;
    private HandlerThread thread;

    private final Object lock = new Object();
    private final long[] ts = new long[N];
    private final float[][] qr = new float[N][4];
    private final float[][] qs = new float[N][4];
    private int head = -1, count = 0;

    private final float[] raw = new float[4];
    private final float[] smooth = new float[4];
    private boolean init;
    private long lastTs;
    private final float[] lastRawMat = new float[9];

    // ---- configuración (la cambia la UI) ----
    volatile float tau = 0.25f;                       // constante de suavizado (s)
    volatile float maxDev = 0.12f;                    // desviación máxima virtual-real (rad)
    volatile float maxTilt = (float) Math.toRadians(25);
    volatile float offset = 0f;                       // rotación manual (rad)
    volatile float zero = 0f;                         // calibración (rad)
    volatile boolean digital = false;                 // suavizar yaw/pitch/roll
    volatile boolean level = false;                   // nivelar horizonte
    volatile boolean invert = false;
    volatile long syncNs = 0;
    volatile boolean comparable = true;               // timestamps cámara == timestamps sensor
    volatile int rotDeg = 90;                         // rotación del display en grados
    volatile float liveTiltDeg = 0f;                  // inclinación actual (para el indicador)
    volatile boolean available = false;

    // scratch (solo hilo GL)
    private final float[] Rr = new float[9], Rs = new float[9], Rv = new float[9];
    private final float[] tmpA = new float[9], tmpB = new float[9], tmpC = new float[9], Rz = new float[9];
    private final float[] Md = new float[9];
    private float zoomState = 1f;

    HorizonEngine(Context c) {
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
    }

    void start() {
        if (sensor != null) return;
        sensor = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
        if (sensor == null) sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (sensor == null) { available = false; return; }
        thread = new HandlerThread("HorizonSensors");
        thread.start();
        synchronized (lock) { init = false; head = -1; count = 0; }
        zoomState = 1f;
        available = sm.registerListener(this, sensor, 5000, new Handler(thread.getLooper()));
    }

    void stop() {
        if (sensor == null) return;
        sm.unregisterListener(this);
        sensor = null;
        if (thread != null) { thread.quitSafely(); thread = null; }
    }

    /** Pone a cero el nivel actual. Devuelve los grados que estaba desviado. */
    float calibrate() {
        float t = tiltOf(lastRawMat, rotDeg);
        zero = t;
        return (float) Math.toDegrees(t);
    }

    @Override public void onAccuracyChanged(Sensor s, int a) { }

    @Override public void onSensorChanged(SensorEvent e) {
        float[] q = new float[4];
        SensorManager.getQuaternionFromVector(q, e.values);   // w,x,y,z
        float n = (float) Math.sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
        if (n < 1e-6f) return;
        for (int i = 0; i < 4; i++) q[i] /= n;

        if (!init) {
            System.arraycopy(q, 0, raw, 0, 4);
            System.arraycopy(q, 0, smooth, 0, 4);
            init = true;
            lastTs = e.timestamp;
        } else {
            if (dot(q, raw) < 0) for (int i = 0; i < 4; i++) q[i] = -q[i];
            System.arraycopy(q, 0, raw, 0, 4);
            float dt = (e.timestamp - lastTs) * 1e-9f;
            lastTs = e.timestamp;
            if (dt < 0.0005f) dt = 0.0005f;
            if (dt > 0.05f) dt = 0.05f;
            float a = digital ? (float) (1.0 - Math.exp(-dt / Math.max(0.01f, tau))) : 1f;
            slerp(smooth, raw, a);
            // la cámara virtual no se puede alejar más de maxDev de la real (si no, aparecen bordes)
            float d = Math.min(1f, Math.abs(dot(smooth, raw)));
            float ang = (float) (2.0 * Math.acos(d));
            if (ang > maxDev) slerp(smooth, raw, 1f - maxDev / ang);
        }

        synchronized (lock) {
            head = (head + 1) % N;
            if (count < N) count++;
            ts[head] = e.timestamp;
            System.arraycopy(raw, 0, qr[head], 0, 4);
            System.arraycopy(smooth, 0, qs[head], 0, 4);
        }
        quatToMat(raw, lastRawMat);
        liveTiltDeg = (float) Math.toDegrees(tiltOf(lastRawMat, rotDeg) - zero + offset);
    }

    private int find(long target) {
        // llamado con lock tomado
        if (count == 0) return -1;
        int idx = head;
        for (int i = 0; i < count; i++) {
            if (ts[idx] <= target) return idx;
            int prev = (idx - 1 + N) % N;
            if (i == count - 1) return idx;
            idx = prev;
        }
        return head;
    }

    /**
     * Calcula la homografía (column-major, lista para glUniformMatrix3fv) y el zoom.
     * @param f focal en unidades de medio ancho de imagen (1/tan(hfov/2))
     */
    void compute(long frameTs, int rd, float f, float aspect, float[] outM, float[] outZoom) {
        if (!(digital || level)) { identity(outM); outZoom[0] = 1f; zoomState = 1f; return; }
        boolean ok;
        synchronized (lock) {
            long target = comparable ? frameTs + syncNs : Long.MAX_VALUE;
            int idx = find(target);
            ok = idx >= 0;
            if (ok) { quatToMat(qr[idx], Rr); quatToMat(qs[idx], Rs); }
        }
        if (!ok) { identity(outM); outZoom[0] = 1f; return; }

        if (level) {
            float t = tiltOf(Rs, rd) - zero + offset;
            float mt = maxTilt;
            if (t > mt) t = mt; else if (t < -mt) t = -mt;
            if (invert) t = -t;
            rz(-t, Rz);
            mul(Rs, Rz, Rv);
        } else {
            System.arraycopy(Rs, 0, Rv, 0, 9);
            if (offset != 0f) { rz(-offset, Rz); mul(Rs, Rz, Rv); }
        }

        // M = Rr^T * Rv   (espacio del dispositivo)
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++) {
                float s = 0;
                for (int k = 0; k < 3; k++) s += Rr[k * 3 + i] * Rv[k * 3 + j];
                tmpA[i * 3 + j] = s;
            }
        // pasar al espacio del display: Rd * M * Rd^T
        float ang = (float) Math.toRadians(rd);
        rz(ang, tmpB);                       // Rd
        mul(tmpB, tmpA, tmpC);               // Rd*M
        float[] rdT = new float[9];
        transpose(tmpB, rdT);
        mul(tmpC, rdT, Md);

        // zoom necesario: esquinas del frame virtual -> frame real
        float need = 1f;
        float[] cx = {-1, 1, -1, 1};
        float[] cy = {-aspect, -aspect, aspect, aspect};
        for (int c = 0; c < 4; c++) {
            float dx = cx[c] / f, dy = cy[c] / f, dz = -1f;
            float rx = Md[0] * dx + Md[1] * dy + Md[2] * dz;
            float ry = Md[3] * dx + Md[4] * dy + Md[5] * dz;
            float rzz = Md[6] * dx + Md[7] * dy + Md[8] * dz;
            if (rzz > -1e-3f) { need = 2.5f; break; }
            float nx = Math.abs(rx / -rzz * f);
            float ny = Math.abs(ry / -rzz * f) / aspect;
            float r = Math.max(nx, ny);
            if (r > need) need = r;
        }
        need = Math.min(2.5f, need * 1.02f);
        zoomState = Math.max(need, zoomState * 0.985f);
        if (zoomState < 1f) zoomState = 1f;
        outZoom[0] = zoomState;

        // row-major -> column-major
        for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) outM[c * 3 + r] = Md[r * 3 + c];
    }

    // ------------------------------------------------------------------ matemática

    /** Inclinación del display respecto al horizonte (rad), reducida a [-45°,45°] (cualquier agarre). */
    static float tiltOf(float[] R, int rotDeg) {
        float gx = R[6], gy = R[7];
        double a = Math.toRadians(rotDeg);
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        float dx = gx * c - gy * s;
        float dy = gx * s + gy * c;
        float t = (float) Math.atan2(dx, dy);
        t -= HALF_PI * (float) Math.rint(t / HALF_PI);
        return t;
    }

    private static void identity(float[] m) {
        for (int i = 0; i < 9; i++) m[i] = 0;
        m[0] = m[4] = m[8] = 1;
    }

    private static void rz(float a, float[] o) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        o[0] = c; o[1] = -s; o[2] = 0;
        o[3] = s; o[4] = c;  o[5] = 0;
        o[6] = 0; o[7] = 0;  o[8] = 1;
    }

    private static void mul(float[] a, float[] b, float[] o) {
        float[] t = new float[9];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                t[i * 3 + j] = a[i * 3] * b[j] + a[i * 3 + 1] * b[3 + j] + a[i * 3 + 2] * b[6 + j];
        System.arraycopy(t, 0, o, 0, 9);
    }

    private static void transpose(float[] a, float[] o) {
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) o[j * 3 + i] = a[i * 3 + j];
    }

    private static float dot(float[] a, float[] b) {
        return a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3];
    }

    /** a = slerp(a, b, t) */
    private static void slerp(float[] a, float[] b, float t) {
        float d = dot(a, b);
        float sgn = d < 0 ? -1f : 1f;
        d *= sgn;
        float k0, k1;
        if (d > 0.9995f) {
            k0 = 1f - t; k1 = t * sgn;
        } else {
            float th = (float) Math.acos(d);
            float s = (float) Math.sin(th);
            k0 = (float) Math.sin((1f - t) * th) / s;
            k1 = (float) Math.sin(t * th) / s * sgn;
        }
        float n = 0;
        for (int i = 0; i < 4; i++) { a[i] = k0 * a[i] + k1 * b[i]; n += a[i] * a[i]; }
        n = (float) Math.sqrt(n);
        if (n > 0) for (int i = 0; i < 4; i++) a[i] /= n;
    }

    /** q = (w,x,y,z) -> matriz 3x3 row-major (dispositivo -> mundo) */
    private static void quatToMat(float[] q, float[] m) {
        float w = q[0], x = q[1], y = q[2], z = q[3];
        m[0] = 1 - 2 * (y * y + z * z); m[1] = 2 * (x * y - w * z);     m[2] = 2 * (x * z + w * y);
        m[3] = 2 * (x * y + w * z);     m[4] = 1 - 2 * (x * x + z * z); m[5] = 2 * (y * z - w * x);
        m[6] = 2 * (x * z - w * y);     m[7] = 2 * (y * z + w * x);     m[8] = 1 - 2 * (x * x + y * y);
    }
}
