package com.camaramod.glass;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Rational;
import android.util.Size;
import android.util.SizeF;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.IntConsumer;

public class MainActivity extends Activity implements TextureView.SurfaceTextureListener {

    // ============================================================ modos
    static final String[] MODE_NAMES = {"Desactivado (Steady Off)", "Superstable (Steady On)", "Super steady Pro",
            "Superstable + Horizon Lock", "Solo Horizon Lock"};
    static final String[] MODE_SHORT = {"Off", "Steady", "Pro", "Pro + Horizon", "Horizon"};
    static final String[] MODE_DESC = {"Sin estabilización", "OIS + EIS del hardware",
            "OIS + estabilización digital con giroscopio", "Pro + horizonte siempre nivelado",
            "Solo nivela el horizonte (giro 360°)"};
    static final int[] MODE_ICONS = {R.drawable.ic_off, R.drawable.ic_steady, R.drawable.ic_pro,
            R.drawable.ic_steady_horizon, R.drawable.ic_horizon};

    static final class Lens {
        String id;
        int facing;
        float focal, hfov, eq;
        int orientation;
        boolean ois, eis, flash, tsRealtime;
        String label = "";
        List<Size> sizes = new ArrayList<>();
        CameraCharacteristics ch;
    }

    // ============================================================ estado
    private SharedPreferences prefs;
    private CameraManager cm;
    private final List<Lens> lenses = new ArrayList<>();
    private Lens cur;
    private Size size;
    private boolean torch = false;
    private boolean recording = false;
    private long recStart;

    private HorizonEngine engine;
    private GlPipeline pipe;
    private CameraDevice camDev;
    private CameraCaptureSession session;
    private HandlerThread camThread;
    private Handler camH;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private MediaRecorder recorder;
    private Uri recUri;
    private ParcelFileDescriptor recPfd;

    // UI
    private FrameLayout root, hud;
    private TextureView tv;
    private Glass.Overlay overlay;
    private TextView modeLabel, infoLabel;
    private ImageView modeIcon, btnTorch;
    private Glass.RecButton recBtn;
    private LinearLayout lensPill, panelBody;
    private FrameLayout panel;
    private SurfaceTexture pendingSt;

    // ============================================================ ciclo de vida
    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        Glass.init(this);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        engine = new HorizonEngine(this);
        buildUi();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, 1);
        }
    }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                && tv.isAvailable() && pipe == null) startAll(tv.getSurfaceTexture());
    }

    @Override protected void onResume() {
        super.onResume();
        camThread = new HandlerThread("cam");
        camThread.start();
        camH = new Handler(camThread.getLooper());
        engine.start();
        if (!engine.available) Toast.makeText(this, "Este teléfono no tiene sensor de rotación: sin horizon lock", Toast.LENGTH_LONG).show();
        if (tv.isAvailable() && pipe == null
                && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            startAll(tv.getSurfaceTexture());
        ui.post(tick);
        hideSystemUi();
    }

    @Override protected void onPause() {
        ui.removeCallbacks(tick);
        if (recording) stopRec();
        stopAll();
        engine.stop();
        if (camThread != null) { camThread.quitSafely(); camThread = null; }
        super.onPause();
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) hideSystemUi();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    // ============================================================ TextureView
    @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
        if (pipe == null && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            startAll(st);
    }
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) { }
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        if (recording) stopRec();
        stopAll();
        return true;
    }
    @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }

    // ============================================================ arranque / parada
    private void startAll(SurfaceTexture st) {
        if (lenses.isEmpty()) loadLenses();
        if (lenses.isEmpty()) { Toast.makeText(this, "No se encontraron cámaras", Toast.LENGTH_LONG).show(); return; }
        String want = prefs.getString("lens", "");
        cur = null;
        for (Lens l : lenses) if (l.id.equals(want)) cur = l;
        if (cur == null) cur = mainBack();
        pickSize();
        fitPreview();
        rebuildLensPill();
        engine.rotDeg = rotationDeg();

        pipe = new GlPipeline(engine);
        pipe.setDisplayRotation(rotationDeg());
        applyParams();
        applyEngineConfig();
        pipe.start(st, size.getWidth(), size.getHeight(), () -> ui.post(this::openCamera));
        refreshLabels();
    }

    private void stopAll() {
        closeCamera();
        if (pipe != null) { pipe.release(); pipe = null; }
    }

    private void closeCamera() {
        try { if (session != null) session.close(); } catch (Exception ignored) { }
        session = null;
        try { if (camDev != null) camDev.close(); } catch (Exception ignored) { }
        camDev = null;
    }

    @SuppressWarnings("MissingPermission")
    private void openCamera() {
        if (pipe == null || cur == null) return;
        try {
            cm.openCamera(cur.id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice d) {
                    if (pipe == null) { d.close(); return; }
                    camDev = d;
                    createSession();
                }
                @Override public void onDisconnected(CameraDevice d) { d.close(); if (camDev == d) camDev = null; }
                @Override public void onError(CameraDevice d, int e) {
                    d.close();
                    camDev = null;
                    ui.post(() -> {
                        Toast.makeText(MainActivity.this, "No se pudo abrir la cámara " + cur.id, Toast.LENGTH_SHORT).show();
                        Lens mb = mainBack();
                        if (mb != null && mb != cur) selectLens(mb);
                    });
                }
            }, camH);
        } catch (Exception e) {
            Toast.makeText(this, "Error abriendo cámara: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void createSession() {
        try {
            pipe.getCameraTexture().setDefaultBufferSize(size.getWidth(), size.getHeight());
            camDev.createCaptureSession(Collections.singletonList(pipe.getCameraSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession s) {
                            session = s;
                            updateRepeating();
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession s) {
                            ui.post(() -> Toast.makeText(MainActivity.this, "Config de cámara fallida (probá otra resolución)", Toast.LENGTH_LONG).show());
                        }
                    }, camH);
        } catch (Exception e) {
            ui.post(() -> Toast.makeText(this, "Sesión: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private void updateRepeating() {
        if (camDev == null || session == null || pipe == null) return;
        try {
            CaptureRequest.Builder b = camDev.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            b.addTarget(pipe.getCameraSurface());
            b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);

            Range<Integer> fr = pickFps(cur, size, prefs.getInt("fps", 30));
            if (fr != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fr);

            Range<Integer> evr = cur.ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            Rational step = cur.ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP);
            if (evr != null && step != null && step.floatValue() > 0) {
                int idx = Math.round(prefs.getInt("ev", 0) / step.floatValue());
                idx = Math.max(evr.getLower(), Math.min(evr.getUpper(), idx));
                b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, idx);
            }

            int[] afs = cur.ch.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES);
            int af = prefs.getInt("af", 0);
            if (afs != null) {
                if (af == 0 && has(afs, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO))
                    b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
                else if (af == 1 && has(afs, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE))
                    b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                else if (af == 2 && has(afs, CaptureRequest.CONTROL_AF_MODE_OFF)) {
                    b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF);
                    b.set(CaptureRequest.LENS_FOCUS_DISTANCE, 0f);
                }
            }

            int mode = prefs.getInt("mode", 2);
            if (cur.ois)
                b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, mode != 0
                        ? CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON : CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF);
            if (cur.eis)
                b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, mode == 1
                        ? CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON : CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF);
            if (cur.flash)
                b.set(CaptureRequest.FLASH_MODE, torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);

            session.setRepeatingRequest(b.build(), null, camH);
        } catch (CameraAccessException | IllegalStateException e) {
            // la sesión se está cerrando
        }
    }

    private static boolean has(int[] a, int v) { for (int x : a) if (x == v) return true; return false; }

    // ============================================================ cámaras / tamaños
    private void loadLenses() {
        lenses.clear();
        Set<String> ids = new LinkedHashSet<>();
        try { ids.addAll(Arrays.asList(cm.getCameraIdList())); } catch (Exception ignored) { }
        // IDs ocultos de lentes físicas (ultra gran angular, tele) en muchos teléfonos
        for (int i = 0; i <= 9; i++) ids.add(String.valueOf(i));
        for (int i = 20; i <= 29; i++) ids.add(String.valueOf(i));
        Set<String> seen = new LinkedHashSet<>();
        for (String id : ids) {
            try {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (facing == null || facing == CameraCharacteristics.LENS_FACING_EXTERNAL) continue;
                StreamConfigurationMap map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                float[] fl = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                SizeF ps = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
                if (map == null || fl == null || fl.length == 0 || ps == null) continue;
                Size[] ss = map.getOutputSizes(SurfaceTexture.class);
                if (ss == null || ss.length == 0) continue;

                Lens l = new Lens();
                l.id = id;
                l.ch = ch;
                l.facing = facing;
                l.focal = fl[0];
                String key = facing + ":" + Math.round(l.focal * 100) + ":" + Math.round(ps.getWidth() * 100);
                if (!seen.add(key)) continue;
                l.hfov = (float) (2.0 * Math.atan(ps.getWidth() / (2.0 * l.focal)));
                float diag = (float) Math.hypot(ps.getWidth(), ps.getHeight());
                l.eq = l.focal * 43.27f / diag;
                Integer so = ch.get(CameraCharacteristics.SENSOR_ORIENTATION);
                l.orientation = so == null ? 90 : so;
                int[] oisM = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION);
                l.ois = oisM != null && has(oisM, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON);
                int[] eisM = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
                l.eis = eisM != null && has(eisM, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON);
                Boolean fa = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                l.flash = fa != null && fa;
                Integer tsrc = ch.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE);
                l.tsRealtime = tsrc != null && tsrc == CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME;

                for (Size s : ss) {
                    float ar = (float) s.getWidth() / s.getHeight();
                    boolean ok = (Math.abs(ar - 16f / 9f) < 0.03f || Math.abs(ar - 4f / 3f) < 0.03f)
                            && s.getWidth() >= 1280 && s.getWidth() <= 4096;
                    if (ok) l.sizes.add(s);
                }
                Collections.sort(l.sizes, (a, c) -> Integer.compare(c.getWidth() * c.getHeight(), a.getWidth() * a.getHeight()));
                if (l.sizes.isEmpty()) continue;
                lenses.add(l);
            } catch (Exception ignored) { }
        }
        // etiquetas "0.5x / 1x / 3x" relativas a la lente principal trasera
        Lens main = mainBack();
        for (Lens l : lenses) {
            if (l.facing == CameraCharacteristics.LENS_FACING_FRONT) { l.label = "Selfie"; continue; }
            float r = main == null ? 1f : l.eq / main.eq;
            l.label = Math.abs(r - Math.round(r)) < 0.12f ? Math.round(r) + "×" : String.format(Locale.US, "%.1f×", r);
        }
        Collections.sort(lenses, (a, c) -> {
            if (a.facing != c.facing) return a.facing == CameraCharacteristics.LENS_FACING_BACK ? -1 : 1;
            return Float.compare(a.eq, c.eq);
        });
    }

    /** Lente trasera principal: la de ID "0" si existe; si no, la de equivalente más cercano a 26 mm. */
    private Lens mainBack() {
        Lens best = null;
        for (Lens l : lenses) {
            if (l.facing != CameraCharacteristics.LENS_FACING_BACK) continue;
            if (l.id.equals("0")) return l;
            if (best == null || Math.abs(l.eq - 26) < Math.abs(best.eq - 26)) best = l;
        }
        return best != null ? best : (lenses.isEmpty() ? null : lenses.get(0));
    }

    private void pickSize() {
        String want = prefs.getString("res", "1920x1080");
        size = null;
        for (Size s : cur.sizes) if ((s.getWidth() + "x" + s.getHeight()).equals(want)) size = s;
        if (size == null) {
            for (Size s : cur.sizes) if (s.getHeight() == 1080 && s.getWidth() == 1920) size = s;
        }
        if (size == null) size = cur.sizes.get(cur.sizes.size() - 1 > 0 ? Math.min(1, cur.sizes.size() - 1) : 0);
    }

    private Range<Integer> pickFps(Lens l, Size s, int fps) {
        Range<Integer>[] rs = l.ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
        if (rs == null) return null;
        Range<Integer> best = null;
        for (Range<Integer> r : rs) {
            if (r.getUpper() != fps) continue;
            if (best == null || r.getLower() > best.getLower()) best = r;
        }
        return best;
    }

    private List<Integer> fpsOptions() {
        List<Integer> o = new ArrayList<>();
        StreamConfigurationMap map = cur.ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        double maxFps = 30;
        if (map != null) {
            long d = map.getOutputMinFrameDuration(SurfaceTexture.class, size);
            if (d > 0) maxFps = 1e9 / d;
        }
        for (int f : new int[]{24, 30, 60, 120}) {
            if (f <= maxFps + 1 && pickFps(cur, size, f) != null) o.add(f);
        }
        if (o.isEmpty()) o.add(30);
        return o;
    }

    // ============================================================ parámetros de estabilización
    private void applyParams() {
        if (pipe == null || cur == null || size == null) return;
        boolean front = cur.facing == CameraCharacteristics.LENS_FACING_FRONT;
        float f = (float) (1.0 / Math.tan(cur.hfov / 2.0));
        float aspect = (float) size.getHeight() / size.getWidth();
        int mode = prefs.getInt("mode", 2);
        pipe.setParams(f, aspect, cur.orientation, front, mode >= 2, cur.tsRealtime);
    }

    private void applyEngineConfig() {
        int mode = prefs.getInt("mode", 2);
        float[] taus = {0.12f, 0.25f, 0.45f, 0.8f};
        float[] zmax = {1.10f, 1.16f, 1.24f, 1.34f};
        int st = Math.max(0, Math.min(3, prefs.getInt("strength", 1)));
        engine.digital = mode == 2 || mode == 3;
        engine.level = mode == 3 || mode == 4;
        engine.tau = taus[st];
        float hf = cur != null ? cur.hfov : 1.1f;
        engine.maxDev = 0.5f * hf * (1f - 1f / zmax[st]);
        engine.maxTilt = (float) Math.toRadians(prefs.getInt("maxTilt", 25));
        engine.offset = (float) Math.toRadians(prefs.getFloat("rot", 0f));
        engine.invert = prefs.getInt("invert", 0) == 1;
        engine.syncNs = prefs.getInt("sync", 0) * 1_000_000L;
        engine.zero = prefs.getFloat("zero", 0f);
        if (overlay != null) { overlay.grid = prefs.getInt("grid", 0) == 1; overlay.showLevel = mode >= 3 || mode == 4; }
    }

    private void applyMode() {
        applyParams();
        applyEngineConfig();
        updateRepeating();
        refreshLabels();
    }

    private int rotationDeg() {
        int r = getWindowManager().getDefaultDisplay().getRotation();
        return r * 90;
    }

    // ============================================================ cambio de lente
    private void selectLens(Lens l) {
        if (l == null || pipe == null || recording) return;
        cur = l;
        prefs.edit().putString("lens", l.id).apply();
        closeCamera();
        pickSize();
        fitPreview();
        pipe.getCameraTexture().setDefaultBufferSize(size.getWidth(), size.getHeight());
        applyParams();
        applyEngineConfig();
        rebuildLensPill();
        refreshLabels();
        openCamera();
    }

    private void flipCamera() {
        if (cur == null) return;
        Lens target = null;
        if (cur.facing == CameraCharacteristics.LENS_FACING_FRONT) target = mainBack();
        else for (Lens l : lenses) if (l.facing == CameraCharacteristics.LENS_FACING_FRONT) { target = l; break; }
        if (target != null) selectLens(target);
        else Toast.makeText(this, "No hay otra cámara", Toast.LENGTH_SHORT).show();
    }

    // ============================================================ grabación
    private void toggleRec() { if (recording) stopRec(); else startRec(); }

    private void startRec() {
        if (pipe == null || camDev == null) return;
        try {
            String name = "CamaraMod_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CamaraMod");
            cv.put(MediaStore.Video.Media.IS_PENDING, 1);
            recUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
            recPfd = getContentResolver().openFileDescriptor(recUri, "rw");

            int fps = prefs.getInt("fps", 30);
            boolean hevc = prefs.getInt("codec", 0) == 1;
            int mbps = prefs.getInt("mbps", 0);
            long bitrate = mbps > 0 ? mbps * 1_000_000L
                    : (long) (size.getWidth() * (double) size.getHeight() * fps * (hevc ? 0.10 : 0.15));
            bitrate = Math.max(4_000_000L, Math.min(150_000_000L, bitrate));
            boolean audio = prefs.getInt("audio", 1) == 1
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;

            recorder = new MediaRecorder();
            if (audio) recorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
            recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setOutputFile(recPfd.getFileDescriptor());
            recorder.setVideoSize(size.getWidth(), size.getHeight());
            recorder.setVideoFrameRate(fps);
            recorder.setVideoEncodingBitRate((int) bitrate);
            recorder.setVideoEncoder(hevc ? MediaRecorder.VideoEncoder.HEVC : MediaRecorder.VideoEncoder.H264);
            if (audio) {
                recorder.setAudioEncodingBitRate(192_000);
                recorder.setAudioSamplingRate(48_000);
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            }
            recorder.prepare();
            pipe.startRecording(recorder.getSurface());
            recorder.start();
            recording = true;
            recStart = System.currentTimeMillis();
            recBtn.setRecording(true);
            hidePanel();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo grabar: " + e.getMessage() + "\n(probá menos resolución o H.264)", Toast.LENGTH_LONG).show();
            abortRec();
        }
    }

    private void stopRec() {
        recording = false;
        recBtn.setRecording(false);
        if (pipe != null) pipe.stopRecording();
        try { recorder.stop(); } catch (Exception ignored) { }
        try { recorder.release(); } catch (Exception ignored) { }
        recorder = null;
        try { if (recPfd != null) recPfd.close(); } catch (Exception ignored) { }
        recPfd = null;
        if (recUri != null) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Video.Media.IS_PENDING, 0);
            getContentResolver().update(recUri, cv, null, null);
            Toast.makeText(this, "Guardado en Películas/CamaraMod", Toast.LENGTH_SHORT).show();
            recUri = null;
        }
    }

    private void abortRec() {
        recording = false;
        recBtn.setRecording(false);
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) { }
        recorder = null;
        try { if (recPfd != null) recPfd.close(); } catch (Exception ignored) { }
        recPfd = null;
        if (recUri != null) { getContentResolver().delete(recUri, null, null); recUri = null; }
    }

    // ============================================================ bucle de UI
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            int rd = rotationDeg();
            if (pipe != null) pipe.setDisplayRotation(rd);
            engine.rotDeg = rd;
            overlay.invalidate();
            if (recording) {
                long s = (System.currentTimeMillis() - recStart) / 1000;
                infoLabel.setText(String.format(Locale.US, "● %02d:%02d", s / 60, s % 60));
                infoLabel.setTextColor(0xFFFF6B6B);
            } else refreshLabels();
            ui.postDelayed(this, 100);
        }
    };

    private void refreshLabels() {
        if (modeLabel == null || size == null) return;
        int mode = prefs.getInt("mode", 2);
        modeLabel.setText(MODE_SHORT[mode]);
        modeIcon.setImageResource(MODE_ICONS[mode]);
        String res = size.getHeight() >= 2160 ? "4K" : size.getHeight() + "p";
        infoLabel.setText(res + " · " + prefs.getInt("fps", 30) + " fps");
        infoLabel.setTextColor(Color.WHITE);
    }

    private void fitPreview() {
        if (size == null) return;
        root.post(() -> {
            int W = root.getWidth(), H = root.getHeight();
            if (W == 0 || H == 0) return;
            float ar = (float) size.getWidth() / size.getHeight();
            int w = W, h = Math.round(W / ar);
            if (h > H) { h = H; w = Math.round(H * ar); }
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h, Gravity.CENTER);
            tv.setLayoutParams(lp);
            overlay.setLayoutParams(new FrameLayout.LayoutParams(w, h, Gravity.CENTER));
        });
    }

    // ============================================================ construcción de la UI
    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        tv = new TextureView(this);
        tv.setSurfaceTextureListener(this);
        root.addView(tv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

        overlay = new Glass.Overlay(this);
        overlay.engine = engine;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

        hud = new FrameLayout(this);
        root.addView(hud, new FrameLayout.LayoutParams(-1, -1));
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            @SuppressWarnings("deprecation") int l = ins.getSystemWindowInsetLeft();
            @SuppressWarnings("deprecation") int t = ins.getSystemWindowInsetTop();
            @SuppressWarnings("deprecation") int r = ins.getSystemWindowInsetRight();
            @SuppressWarnings("deprecation") int b = ins.getSystemWindowInsetBottom();
            hud.setPadding(l, t, r, b);
            return ins;
        });

        int m = Glass.dp(14);

        // --- modo (arriba-izquierda)
        LinearLayout modePill = new LinearLayout(this);
        modePill.setOrientation(LinearLayout.HORIZONTAL);
        modePill.setGravity(Gravity.CENTER_VERTICAL);
        modePill.setPadding(Glass.dp(12), Glass.dp(8), Glass.dp(16), Glass.dp(8));
        modePill.setBackground(new Glass.Bg(-1, false, 0x2258B8FF));
        modeIcon = new ImageView(this);
        modePill.addView(modeIcon, new LinearLayout.LayoutParams(Glass.dp(22), Glass.dp(22)));
        modeLabel = text(14f, true);
        modeLabel.setPadding(Glass.dp(8), 0, 0, 0);
        modePill.addView(modeLabel);
        modePill.setOnClickListener(v -> showModes());
        Glass.press(modePill);
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        mp.setMargins(m, m, 0, 0);
        hud.addView(modePill, mp);

        // --- info (arriba-centro)
        infoLabel = text(13f, true);
        infoLabel.setPadding(Glass.dp(16), Glass.dp(8), Glass.dp(16), Glass.dp(8));
        infoLabel.setBackground(new Glass.Bg(-1, false, 0));
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        ip.setMargins(0, m, 0, 0);
        hud.addView(infoLabel, ip);

        // --- lentes (izquierda)
        lensPill = new LinearLayout(this);
        lensPill.setOrientation(LinearLayout.VERTICAL);
        lensPill.setGravity(Gravity.CENTER_HORIZONTAL);
        lensPill.setPadding(Glass.dp(6), Glass.dp(6), Glass.dp(6), Glass.dp(6));
        lensPill.setBackground(new Glass.Bg(30, false, 0));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.CENTER_VERTICAL);
        lp.setMargins(m, 0, 0, 0);
        hud.addView(lensPill, lp);

        // --- columna derecha
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER_HORIZONTAL);
        right.setPadding(Glass.dp(8), Glass.dp(10), Glass.dp(8), Glass.dp(10));
        right.setBackground(new Glass.Bg(40, false, 0));

        ImageView bSet = Glass.iconButton(this, R.drawable.ic_settings, 46);
        bSet.setOnClickListener(v -> showSettings());
        right.addView(bSet, new LinearLayout.LayoutParams(Glass.dp(46), Glass.dp(46)));

        ImageView bFlip = Glass.iconButton(this, R.drawable.ic_flip, 46);
        bFlip.setOnClickListener(v -> flipCamera());
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(Glass.dp(46), Glass.dp(46));
        fl.topMargin = Glass.dp(8);
        right.addView(bFlip, fl);

        recBtn = new Glass.RecButton(this);
        recBtn.setOnClickListener(v -> toggleRec());
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(Glass.dp(76), Glass.dp(76));
        rl.topMargin = Glass.dp(10);
        right.addView(recBtn, rl);

        btnTorch = Glass.iconButton(this, R.drawable.ic_torch, 46);
        btnTorch.setOnClickListener(v -> {
            if (cur == null || !cur.flash) { Toast.makeText(this, "Esta lente no tiene flash", Toast.LENGTH_SHORT).show(); return; }
            torch = !torch;
            btnTorch.setBackground(new Glass.Bg(-1, torch, torch ? 0x66FFD66B : 0));
            updateRepeating();
        });
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(Glass.dp(46), Glass.dp(46));
        tl.topMargin = Glass.dp(10);
        right.addView(btnTorch, tl);

        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL);
        rp.setMargins(0, 0, m, 0);
        hud.addView(right, rp);

        // --- panel flotante
        panel = new FrameLayout(this);
        panel.setBackground(new Glass.Bg(26, false, 0x30101830));
        panel.setVisibility(View.GONE);
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        panelBody = new LinearLayout(this);
        panelBody.setOrientation(LinearLayout.VERTICAL);
        panelBody.setPadding(Glass.dp(16), Glass.dp(14), Glass.dp(16), Glass.dp(14));
        sv.addView(panelBody, new ViewGroup.LayoutParams(-1, -2));
        panel.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(Glass.dp(340), -1, Gravity.END);
        pp.setMargins(0, m, Glass.dp(116), m);
        hud.addView(panel, pp);

        setContentView(root);
    }

    private TextView text(float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setTextSize(sp);
        t.setTextColor(Color.WHITE);
        if (bold) t.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        return t;
    }

    private void rebuildLensPill() {
        lensPill.removeAllViews();
        for (final Lens l : lenses) {
            boolean sel = l == cur;
            TextView t = new TextView(this);
            t.setText(l.label);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(l.label.length() > 4 ? 11f : 14f);
            t.setTextColor(sel ? Color.WHITE : 0xCCFFFFFF);
            t.setBackground(new Glass.Bg(-1, sel, sel ? 0x5558B8FF : 0));
            t.setOnClickListener(v -> selectLens(l));
            Glass.press(t);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Glass.dp(46), Glass.dp(46));
            p.topMargin = Glass.dp(3);
            p.bottomMargin = Glass.dp(3);
            lensPill.addView(t, p);
        }
    }

    // ------------------------------------------------------------ panel
    private void showPanel() {
        panel.setVisibility(View.VISIBLE);
        panel.setAlpha(0f);
        panel.setTranslationX(Glass.dp(40));
        panel.animate().alpha(1f).translationX(0).setDuration(220).start();
    }

    private void hidePanel() {
        if (panel.getVisibility() != View.VISIBLE) return;
        panel.animate().alpha(0f).translationX(Glass.dp(40)).setDuration(160).withEndAction(() -> panel.setVisibility(View.GONE)).start();
    }

    private void panelHeader(String title) {
        panelBody.removeAllViews();
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(18f, true);
        h.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        t.setText(title);
        ImageView x = Glass.iconButton(this, R.drawable.ic_close, 36);
        x.setOnClickListener(v -> hidePanel());
        h.addView(x, new LinearLayout.LayoutParams(Glass.dp(36), Glass.dp(36)));
        panelBody.addView(h);
    }

    private void showModes() {
        if (panel.getVisibility() == View.VISIBLE) { hidePanel(); return; }
        panelHeader("Sensor y estabilización");
        int sel = prefs.getInt("mode", 2);
        final List<View> rows = new ArrayList<>();
        for (int i = 0; i < MODE_NAMES.length; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Glass.dp(12), Glass.dp(10), Glass.dp(12), Glass.dp(10));
            row.setBackground(new Glass.Bg(20, i == sel, i == sel ? 0x4458B8FF : 0));
            ImageView ic = new ImageView(this);
            ic.setImageResource(MODE_ICONS[i]);
            row.addView(ic, new LinearLayout.LayoutParams(Glass.dp(26), Glass.dp(26)));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(Glass.dp(12), 0, 0, 0);
            TextView n = text(14f, true);
            n.setText(MODE_NAMES[i]);
            TextView d = text(11.5f, false);
            d.setTextColor(0xB3FFFFFF);
            d.setText(MODE_DESC[i]);
            col.addView(n);
            col.addView(d);
            row.addView(col);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = Glass.dp(10);
            panelBody.addView(row, lp);
            rows.add(row);
            row.setOnClickListener(v -> {
                prefs.edit().putInt("mode", idx).apply();
                applyMode();
                for (int k = 0; k < rows.size(); k++)
                    rows.get(k).setBackground(new Glass.Bg(20, k == idx, k == idx ? 0x4458B8FF : 0));
            });
            Glass.press(row);
        }
        showPanel();
    }

    private void showSettings() {
        if (panel.getVisibility() == View.VISIBLE) { hidePanel(); return; }
        panelHeader("Opciones");

        // resolución
        final List<Size> sz = cur.sizes;
        String[] rl = new String[sz.size()];
        int rs = 0;
        for (int i = 0; i < sz.size(); i++) {
            Size s = sz.get(i);
            boolean fourThree = Math.abs((float) s.getWidth() / s.getHeight() - 4f / 3f) < 0.03f;
            rl[i] = (s.getHeight() >= 2160 ? "4K" : s.getHeight() + "p") + (fourThree ? " 4:3" : "");
            if (s.equals(size)) rs = i;
        }
        panelBody.addView(chips("Resolución", rl, rs, i -> {
            if (recording) return;
            prefs.edit().putString("res", sz.get(i).getWidth() + "x" + sz.get(i).getHeight()).apply();
            selectLens(cur);
        }));

        // fps
        final List<Integer> fo = fpsOptions();
        String[] fl = new String[fo.size()];
        int fs = 0;
        for (int i = 0; i < fo.size(); i++) { fl[i] = fo.get(i) + " fps"; if (fo.get(i) == prefs.getInt("fps", 30)) fs = i; }
        panelBody.addView(chips("FPS", fl, fs, i -> { prefs.edit().putInt("fps", fo.get(i)).apply(); updateRepeating(); refreshLabels(); }));

        final int[] br = {0, 10, 20, 40, 80};
        panelBody.addView(chips("Bitrate", new String[]{"Auto", "10", "20", "40", "80 Mbps"}, indexOf(br, prefs.getInt("mbps", 0)),
                i -> prefs.edit().putInt("mbps", br[i]).apply()));
        panelBody.addView(chips("Códec", new String[]{"H.264", "H.265"}, prefs.getInt("codec", 0),
                i -> prefs.edit().putInt("codec", i).apply()));
        panelBody.addView(chips("Audio", new String[]{"Sin audio", "Con audio"}, prefs.getInt("audio", 1),
                i -> prefs.edit().putInt("audio", i).apply()));

        panelBody.addView(chips("Fuerza de estabilización", new String[]{"Suave", "Media", "Fuerte", "Máxima"}, prefs.getInt("strength", 1),
                i -> { prefs.edit().putInt("strength", i).apply(); applyEngineConfig(); }));
        final int[] mt = {10, 15, 25, 35, 45};
        panelBody.addView(chips("Ángulo máx. del horizonte", new String[]{"10°", "15°", "25°", "35°", "45°"}, indexOf(mt, prefs.getInt("maxTilt", 25)),
                i -> { prefs.edit().putInt("maxTilt", mt[i]).apply(); applyEngineConfig(); }));

        final int[] ev = {-2, -1, 0, 1, 2};
        panelBody.addView(chips("Exposición (EV)", new String[]{"-2", "-1", "0", "+1", "+2"}, indexOf(ev, prefs.getInt("ev", 0)),
                i -> { prefs.edit().putInt("ev", ev[i]).apply(); updateRepeating(); }));
        panelBody.addView(chips("Enfoque", new String[]{"Continuo video", "Continuo foto", "Infinito"}, prefs.getInt("af", 0),
                i -> { prefs.edit().putInt("af", i).apply(); updateRepeating(); }));
        panelBody.addView(chips("Cuadrícula", new String[]{"No", "Sí"}, prefs.getInt("grid", 0),
                i -> { prefs.edit().putInt("grid", i).apply(); applyEngineConfig(); }));

        // rotación manual (original: "Rotate the Camera (Degrees)")
        panelBody.addView(stepper("Rotar cámara (grados)", "rot", 0.5f, -15f, 15f));

        final int[] sy = {-30, -15, 0, 15, 30};
        panelBody.addView(chips("Sincronía giroscopio (ms)", new String[]{"-30", "-15", "0", "+15", "+30"}, indexOf(sy, prefs.getInt("sync", 0)),
                i -> { prefs.edit().putInt("sync", sy[i]).apply(); applyEngineConfig(); }));
        panelBody.addView(chips("Invertir giro (si el horizonte se inclina al revés)", new String[]{"No", "Sí"}, prefs.getInt("invert", 0),
                i -> { prefs.edit().putInt("invert", i).apply(); applyEngineConfig(); }));

        TextView cal = Glass.chip(this, "  Calibrar sensores (dejá el teléfono en una superficie plana)  ", false);
        cal.setOnClickListener(v -> {
            float deg = engine.calibrate();
            prefs.edit().putFloat("zero", engine.zero).apply();
            Toast.makeText(this, String.format(Locale.US, "Sensores calibrados y puestos a cero ✓ (%.1f°)", deg), Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, -2);
        cl.topMargin = Glass.dp(16);
        cal.setGravity(Gravity.CENTER);
        panelBody.addView(cal, cl);
        showPanel();
    }

    private static int indexOf(int[] a, int v) { for (int i = 0; i < a.length; i++) if (a[i] == v) return i; return 0; }

    private View chips(String title, String[] labels, int selected, final IntConsumer onPick) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
        bl.topMargin = Glass.dp(14);
        box.setLayoutParams(bl);
        TextView t = text(12f, true);
        t.setTextColor(0xB3FFFFFF);
        t.setText(title);
        box.addView(t);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        final LinearLayout row = new LinearLayout(this);
        final List<TextView> cs = new ArrayList<>();
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView c = Glass.chip(this, labels[i], i == selected);
            c.setOnClickListener(v -> {
                for (int k = 0; k < cs.size(); k++) Glass.styleChip(cs.get(k), k == idx);
                onPick.accept(idx);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Glass.dp(8);
            lp.topMargin = Glass.dp(6);
            row.addView(c, lp);
            cs.add(c);
        }
        hs.addView(row);
        box.addView(hs);
        return box;
    }

    private View stepper(String title, final String key, final float step, final float min, final float max) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
        bl.topMargin = Glass.dp(14);
        box.setLayoutParams(bl);
        TextView t = text(12f, true);
        t.setTextColor(0xB3FFFFFF);
        t.setText(title);
        box.addView(t);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final TextView val = text(16f, true);
        val.setGravity(Gravity.CENTER);
        val.setText(String.format(Locale.US, "%+.1f°", prefs.getFloat(key, 0f)));
        TextView minus = Glass.chip(this, "  −  ", false);
        TextView plus = Glass.chip(this, "  +  ", false);
        minus.setTextSize(18f);
        plus.setTextSize(18f);
        View.OnClickListener l = v -> {
            float cur2 = prefs.getFloat(key, 0f) + (v == plus ? step : -step);
            cur2 = Math.max(min, Math.min(max, cur2));
            prefs.edit().putFloat(key, cur2).apply();
            val.setText(String.format(Locale.US, "%+.1f°", cur2));
            applyEngineConfig();
        };
        minus.setOnClickListener(l);
        plus.setOnClickListener(l);
        LinearLayout.LayoutParams vl = new LinearLayout.LayoutParams(Glass.dp(90), -2);
        row.addView(minus);
        row.addView(val, vl);
        row.addView(plus);
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-2, -2);
        rl.topMargin = Glass.dp(6);
        box.addView(row, rl);
        return box;
    }
}
