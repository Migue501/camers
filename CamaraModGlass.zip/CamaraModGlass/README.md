# CámaraMod Glass

Cámara con estabilización digital por giroscopio, Horizon Lock y UI liquid glass. Reescrita desde cero, inspirada en el CAMARAMOD original (modos Steady Off / On / Pro / +Horizon Lock, rotación manual, calibración de sensores, resolución, FPS, bitrate).

## Compilar
1. Abrí la carpeta con Android Studio (Hedgehog o más nuevo). Va a descargar Gradle 8.2 y el SDK 34.
2. Build > Build APK(s). Mínimo Android 10 (API 29). No usa librerías externas.
3. La primera vez aceptá permisos de cámara y micrófono. Los videos van a Películas/CamaraMod.

## Cómo funciona el Horizon Lock
- Sensor: rotación 3D fusionada (giroscopio + acelerómetro) a ~200 Hz.
- Cada frame de cámara se sincroniza con la muestra del sensor más cercana a su timestamp.
- Un shader aplica una homografía: lo que vería una cámara virtual suavizada y con el horizonte nivelado.
- El zoom se calcula frame a frame, lo justo para tapar los bordes. Se ve y se graba lo mismo.
- Gira 360°: si inclinás el teléfono, el horizonte queda nivelado hasta el "Ángulo máx." elegido.

## Si algo sale al revés
- Horizonte inclinado para el lado contrario: Opciones > Invertir giro > Sí.
- Se ve un "tirón" al moverte: probá Sincronía giroscopio en -15 o +15 ms.
- Horizonte con un pequeño desvío: Calibrar sensores con el teléfono sobre una mesa plana, o ajustá Rotar cámara.

## Limitaciones conocidas
- Pensada para grabar en horizontal (la app queda en landscape).
- La estabilización digital y el horizon lock solo funcionan con cámaras traseras.
- Lentes ocultas (ultra gran angular, tele): depende de que el fabricante exponga los IDs; si no abre, vuelve a la principal.
